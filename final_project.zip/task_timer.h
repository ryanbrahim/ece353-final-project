/*
 * task_timer.h
 *
 *  Created on: Dec 14, 2022
 *      Author: aheto
 */
#include "main.h"
extern TaskHandle_t Task_Accel_Timer_Handle;
#ifndef TASK_TIMER_H_
#define TASK_TIMER_H_

void Task_Accel_Timer(void *pvParameters);



#endif /* TASK_TIMER_H_ */
